﻿using System.Collections;
using System.Collections.Generic;
using System.Resources;
using UnityEngine;

public class ResourceManager
{
	Dictionary<string, UnityEngine.Object> _resources = new Dictionary<string, UnityEngine.Object>();

	public UnityEngine.Object Load<T>(string path)
	{
        if (false == _resources.ContainsKey(path))
        {
			var currentResource = Resources.Load<T>(path);
			_resources.Add(path, currentResource);
		}

		return _resources[path];
	}

	//addressable - Library
	// 중간에 패치
	// DLC
}